<?cs # This default template file is meant to be replaced. ?>
<?cs # Use the -tempatedir arg to javadoc to set your own directory with a replacement for this file in it. ?>

<?cs include:"components/search_box.cs" ?>
<?cs include:"components/api_filter.cs" ?>

<?cs include:"components/masthead.cs" ?>
<?cs include:"components/left_nav.cs" ?>

<?cs include:"customizations.cs" ?>