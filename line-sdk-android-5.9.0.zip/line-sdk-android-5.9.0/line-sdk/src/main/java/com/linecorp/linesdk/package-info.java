/**
 * Provides generic data classes.
 */
package com.linecorp.linesdk;
