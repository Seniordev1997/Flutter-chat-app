package com.linecorp.linesdk.internal;

public enum IdTokenKeyType {
    /**
     * Use JWK for IdToken Signature.
     */
    JWK
}
