/**
 * Provides UI widget classes for easy integration.
 */
package com.linecorp.linesdk.widget;
