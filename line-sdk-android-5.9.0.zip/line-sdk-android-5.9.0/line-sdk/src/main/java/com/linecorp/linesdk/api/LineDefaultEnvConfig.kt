package com.linecorp.linesdk.api

import androidx.annotation.RestrictTo

/**
 * @hide
 * */
@RestrictTo(RestrictTo.Scope.LIBRARY)
internal class LineDefaultEnvConfig : LineEnvConfig()
