package com.linecorp.linesdk;

/**
 * @hide
 * */
public class Constants {
    public static final String LINE_APP_PACKAGE_NAME = "jp.naver.line.android";
}
