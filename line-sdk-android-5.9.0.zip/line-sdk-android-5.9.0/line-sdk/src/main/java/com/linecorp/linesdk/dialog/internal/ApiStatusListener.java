package com.linecorp.linesdk.dialog.internal;

interface ApiStatusListener {

    void onSuccess();

    void onFailure();
}
