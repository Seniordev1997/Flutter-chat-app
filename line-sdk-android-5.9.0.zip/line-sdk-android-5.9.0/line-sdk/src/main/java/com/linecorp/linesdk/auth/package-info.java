/**
 * Provides login related classes, including login intents, parameters, and responses.
 */
package com.linecorp.linesdk.auth;
