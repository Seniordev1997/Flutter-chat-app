package com.linecorp.linesdk;

import android.os.Build;

/**
 * Configuration for test.
 */
public interface TestConfig {
    int TARGET_SDK_VERSION = Build.VERSION_CODES.M;
}
